Music from Newgrounds Audio portal, licensed under 
Creative Commons Attribution Noncommercial Share Alike

Bad Cat [Master Version] by Skullbeatz
http://www.newgrounds.com/audio/listen/376737

The Sound of Epicness by larrylarrybb
http://www.newgrounds.com/audio/listen/358232